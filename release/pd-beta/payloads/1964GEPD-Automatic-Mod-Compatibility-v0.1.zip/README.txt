1964GEPD Auto-Mod Edition - Perfect Dark beta compatibility update

INSTALL
Close 1964 and back up your current 1964.exe and plugin/Mouse_Injector.dll.
Replace BOTH files in your existing complete 1964 GEPD installation.
Keep your INI settings, graphics/audio plugins, saves and ROMs.
Select Mouse Injector as the input plugin and start the ROM from a fresh boot.
Old save states can restore unpatched code.

WHAT'S NEW
Perfect Dark NTSC 6.4 and PAL 28.7 debug/beta support, mouse look and cursor
aiming, EyeSpy pitch, separate E interaction / R reload, beta controller
polling patches, PAL task/EEPROM handling, and recognized original EC
development-cart repair in the loaded copy only. Your ROM file is unchanged.
PAL keeps its native timing. Debug menus use keyboard/controller navigation.

ALSO INCLUDED
The existing GoldenEye/RandomEye/GoldenEye X and Plus support, Plus 2.4 Map
Maker free-camera fix, Map Maker controls, texture-scrolling and Native Test
exit fixes, configurable D-pad/shoulder bindings and generic plugin name.
See RELEASE-NOTES.md for the controls, compatibility details and credits.

CURRENT DOWNLOADS
https://github.com/Madcadden/1964GEPD/releases/tag/automatic-mod-compatibility-v0.2.2
https://github.com/Madcadden/mouse-injector/releases/tag/automatic-mod-compatibility-v0.3.2
The old emulator v0.1 release link serves the same current binaries.

This is an update package. No ROMs, saves or user settings are included.
